// Modul sesi login sederhana (dipakai bersama oleh semua halaman).
// Sesi disimpan di localStorage pada kunci "userLogin" (tanpa password).
var Auth = {
  KUNCI: "userLogin",

  ambilUser: function () {
    try {
      return JSON.parse(localStorage.getItem(this.KUNCI));
    } catch (e) {
      return null;
    }
  },

  simpan: function (user) {
    // password sengaja tidak ikut disimpan di sesi
    localStorage.setItem(this.KUNCI, JSON.stringify({
      id: user.id, nama: user.nama, email: user.email,
      role: user.role, lokasi: user.lokasi
    }));
  },

  // Dipanggil di halaman yang butuh login
  wajibLogin: function () {
    var user = this.ambilUser();
    if (!user) {
      window.location.replace("login.html");
    }
    return user;
  },

  logout: function () {
    localStorage.removeItem(this.KUNCI);
    window.location.replace("login.html");
  }
};
