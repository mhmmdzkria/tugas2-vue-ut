// Logika Vue untuk halaman tracking.html

// ---------- Fungsi bantu ----------
function pad(n) { return String(n).padStart(2, "0"); }

function tanggalHariIni() {
  var d = new Date();
  return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
}

function waktuSekarang() {
  var d = new Date();
  return tanggalHariIni() + " " + pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds());
}

function formKosong() {
  return { nim: "", nama: "", ekspedisi: "", paket: "", tanggalKirim: tanggalHariIni() };
}

new Vue({
  el: "#app",

  data: {
    // sesi login (kalau belum login, otomatis diarahkan ke login.html)
    user: Auth.wajibLogin(),

    pengirimanList: dataBahanAjar.pengirimanList,
    paket: dataBahanAjar.paket,
    stok: dataBahanAjar.stok,
    tracking: JSON.parse(JSON.stringify(dataBahanAjar.tracking)),

    // pencarian
    cariNomor: "",
    hasil: null,
    hasilNomor: "",
    sudahCari: false,

    // form DO baru
    form: formKosong(),
    errors: {},

    pesan: "",
    pesanTipe: "sukses"
  },

  computed: {
    // Nomor DO otomatis: "DO" + tahun berjalan + "-" + sequence 3 digit
    nomorBaru: function () {
      var tahun = new Date().getFullYear();
      var maks = 0;
      Object.keys(this.tracking).forEach(function (kunci) {
        var m = /^DO(\d{4})-(\d+)$/.exec(kunci);
        if (m && Number(m[1]) === tahun) {
          maks = Math.max(maks, Number(m[2]));
        }
      });
      return "DO" + tahun + "-" + String(maks + 1).padStart(3, "0");
    },

    // Object tracking diubah menjadi array agar mudah di-v-for
    daftarDO: function () {
      var self = this;
      return Object.keys(this.tracking).sort().map(function (nomor) {
        return Object.assign({ nomor: nomor }, self.tracking[nomor]);
      });
    },

    paketTerpilih: function () {
      var kode = this.form.paket;
      return this.paket.find(function (p) { return p.kode === kode; }) || null;
    },

    // Isi paket (kode MK) dilengkapi judul & harga dari data stok
    isiPaketDetail: function () {
      if (!this.paketTerpilih) return [];
      var self = this;
      return this.paketTerpilih.isi.map(function (kode) {
        var mk = self.stok.find(function (s) { return s.kode === kode; });
        return { kode: kode, judul: mk ? mk.judul : "(judul tidak ditemukan)", harga: mk ? mk.harga : 0 };
      });
    },

    totalHarga: function () {
      return this.paketTerpilih ? this.paketTerpilih.harga : 0;
    }
  },

  watch: {
    // 1) Hasil pencarian lama dihapus ketika pengguna mengetik nomor baru
    cariNomor: function () {
      this.hasil = null;
      this.sudahCari = false;
    },

    // 2) Error paket hilang otomatis setelah pengguna memilih paket
    "form.paket": function (nilai) {
      if (nilai) this.$delete(this.errors, "paket");
    },

    // 3) Notifikasi hilang otomatis
    pesan: function (nilai) {
      var self = this;
      if (nilai) setTimeout(function () { self.pesan = ""; }, 3000);
    }
  },

  filters: {
    rupiah: function (angka) {
      return "Rp " + Number(angka).toLocaleString("id-ID");
    }
  },

  methods: {
    logout: function () {
      Auth.logout();
    },

    namaPaket: function (kode) {
      var p = this.paket.find(function (x) { return x.kode === kode; });
      return p ? p.kode + " – " + p.nama : kode;
    },

    statusKelas: function (status) {
      if (status === "Diterima" || status === "Selesai") return "selesai";
      if (status === "Diproses") return "proses";
      return "";
    },

    cariDO: function () {
      var nomor = this.cariNomor.trim().toUpperCase();
      this.sudahCari = true;
      if (nomor && this.tracking[nomor]) {
        this.hasil = this.tracking[nomor];
        this.hasilNomor = nomor;
      } else {
        this.hasil = null;
      }
    },

    lihat: function (nomor) {
      this.cariNomor = nomor;           // watcher akan mereset hasil...
      var self = this;
      this.$nextTick(function () {      // ...jadi pencarian dijalankan setelah DOM/watcher selesai
        self.cariDO();
        window.scrollTo({ top: 0, behavior: "smooth" });
      });
    },

    isiHariIni: function () {
      this.form.tanggalKirim = tanggalHariIni();
    },

    validasi: function () {
      var e = {};
      var f = this.form;
      if (!f.nim) e.nim = "NIM wajib diisi.";
      else if (!/^\d{8,12}$/.test(f.nim)) e.nim = "NIM harus 8-12 digit angka.";
      if (!f.nama) e.nama = "Nama wajib diisi.";
      else if (f.nama.length < 3) e.nama = "Nama minimal 3 karakter.";
      if (!f.ekspedisi) e.ekspedisi = "Pilih ekspedisi.";
      if (!f.paket) e.paket = "Pilih paket bahan ajar.";
      if (!f.tanggalKirim) e.tanggalKirim = "Tanggal kirim wajib diisi.";
      return e;
    },

    tambahDO: function () {
      this.errors = this.validasi();
      if (Object.keys(this.errors).length > 0) {
        this.pesanTipe = "bahaya";
        this.pesan = "Periksa kembali isian formulir.";
        return;
      }
      var nomor = this.nomorBaru;
      var f = this.form;
      // $set dipakai karena properti baru pada object tidak reaktif di Vue 2
      this.$set(this.tracking, nomor, {
        nim: f.nim,
        nama: f.nama,
        status: "Diproses",
        ekspedisi: f.ekspedisi,
        tanggalKirim: f.tanggalKirim,
        paket: f.paket,
        total: this.totalHarga,
        perjalanan: [{ waktu: waktuSekarang(), keterangan: "Delivery Order dibuat" }]
      });
      this.pesanTipe = "sukses";
      this.pesan = "DO " + nomor + " berhasil dibuat.";
      this.resetForm();
    },

    resetForm: function () {
      this.form = formKosong();
      this.errors = {};
    }
  }
});
