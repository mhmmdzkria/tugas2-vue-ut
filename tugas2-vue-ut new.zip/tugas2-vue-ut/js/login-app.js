// Logika Vue untuk login.html
// Akun berasal dari dataBahanAjar.pengguna + akun yang didaftarkan lewat formulir (localStorage)

var KUNCI_PENGGUNA_BARU = "penggunaTerdaftar";

function bacaPenggunaBaru() {
  try {
    return JSON.parse(localStorage.getItem(KUNCI_PENGGUNA_BARU)) || [];
  } catch (e) {
    return [];
  }
}

function formDaftarKosong() {
  return { nama: "", email: "", password: "" };
}

new Vue({
  el: "#app",

  data: {
    pengguna: dataBahanAjar.pengguna.concat(bacaPenggunaBaru()),

    // form login
    email: "",
    password: "",
    tampilPassword: false,
    errorLogin: "",

    // modal
    showLupa: false,
    showDaftar: false,
    formDaftar: formDaftarKosong(),
    errorsDaftar: {},
    pesanSukses: ""
  },

  computed: {
    // tombol Login nonaktif selama email/password masih kosong
    formLoginKosong: function () {
      return this.email.trim() === "" || this.password.trim() === "";
    }
  },

  watch: {
    // pesan error hilang begitu pengguna mengetik ulang
    email: function () { this.errorLogin = ""; },
    password: function () { this.errorLogin = ""; },

    // form daftar dibersihkan setiap modal ditutup
    showDaftar: function (terbuka) {
      if (!terbuka) {
        this.formDaftar = formDaftarKosong();
        this.errorsDaftar = {};
      }
    }
  },

  created: function () {
    // sudah login? langsung ke beranda
    if (Auth.ambilUser()) {
      window.location.replace("index.html");
    }
  },

  methods: {
    login: function () {
      var email = this.email.trim().toLowerCase();
      var password = this.password.trim();

      var user = this.pengguna.find(function (u) {
        return u.email.toLowerCase() === email && u.password === password;
      });

      if (user) {
        Auth.simpan(user);
        window.location.href = "index.html";
      } else {
        this.errorLogin = "email/password yang anda masukkan salah";
      }
    },

    daftar: function () {
      var f = this.formDaftar;
      var e = {};
      var email = f.email.trim().toLowerCase();

      if (f.nama.trim().length < 3) e.nama = "Nama minimal 3 karakter.";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) e.email = "Format email tidak valid.";
      else if (this.pengguna.some(function (u) { return u.email.toLowerCase() === email; })) e.email = "Email sudah terdaftar.";
      if (f.password.length < 6) e.password = "Password minimal 6 karakter.";

      this.errorsDaftar = e;
      if (Object.keys(e).length > 0) return;

      var baru = {
        id: this.pengguna.length + 1,
        nama: f.nama.trim(), email: email, password: f.password,
        role: "Pengguna", lokasi: "-"
      };
      this.pengguna.push(baru);
      var tersimpan = bacaPenggunaBaru();
      tersimpan.push(baru);
      localStorage.setItem(KUNCI_PENGGUNA_BARU, JSON.stringify(tersimpan));

      this.showDaftar = false;
      this.email = email;      // isi otomatis agar tinggal memasukkan password
      this.password = "";
      this.pesanSukses = "Akun berhasil dibuat. Silakan login.";
    }
  }
});
