// Logika Vue untuk halaman stok.html
// Data awal berasal dari dataBahanAjar (js/dataBahanAjar.js)

// ---------- Fungsi bantu (di luar instance) ----------
function escapeHtml(teks) {
  return String(teks)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function formKosong() {
  return { kode: "", judul: "", kategori: "", upbjj: "", lokasiRak: "",
           harga: null, qty: null, safety: null, catatan: "" };
}

function adalahBilanganBulat(n, min) {
  return typeof n === "number" && Number.isInteger(n) && n >= min;
}

new Vue({
  el: "#app",

  data: {
    // sesi login (kalau belum login, otomatis diarahkan ke login.html)
    user: Auth.wajibLogin(),

    // data master
    upbjjList: dataBahanAjar.upbjjList,
    kategoriList: dataBahanAjar.kategoriList,
    stok: JSON.parse(JSON.stringify(dataBahanAjar.stok)), // salinan agar data asli aman

    // filter & sort
    filterUpbjj: "",
    filterKategori: "",
    filterReorder: false,
    sortBy: "judul",
    sortDir: "asc",

    // form tambah
    showAddForm: false,
    form: formKosong(),
    formErrors: {},

    // form edit
    editKode: null,
    editForm: {},
    editErrors: {},

    // notifikasi
    pesan: "",
    pesanTipe: "sukses",
    terakhirDiubah: ""
  },

  // ---------- COMPUTED (di-cache, hanya dihitung ulang jika dependensinya berubah) ----------
  computed: {
    // Opsi kategori bergantung pada UT-Daerah yang dipilih (dependent options)
    kategoriTersedia: function () {
      var hasil = [];
      var daerah = this.filterUpbjj;
      this.stok.forEach(function (item) {
        if (item.upbjj === daerah && hasil.indexOf(item.kategori) === -1) {
          hasil.push(item.kategori);
        }
      });
      return hasil;
    },

    // Daftar akhir: filter -> sort
    stokTampil: function () {
      var self = this;
      var data = this.stok.filter(function (item) {
        if (self.filterUpbjj && item.upbjj !== self.filterUpbjj) return false;
        if (self.filterKategori && item.kategori !== self.filterKategori) return false;
        if (self.filterReorder && !(item.qty < item.safety || item.qty === 0)) return false;
        return true;
      });

      var kunci = this.sortBy;
      var arah = this.sortDir === "asc" ? 1 : -1;
      return data.slice().sort(function (a, b) {
        if (kunci === "judul") return a.judul.localeCompare(b.judul) * arah;
        return (a[kunci] - b[kunci]) * arah;
      });
    },

    jumlahReorder: function () {
      return this.stok.filter(function (i) { return i.qty < i.safety || i.qty === 0; }).length;
    }
  },

  // ---------- WATCHERS ----------
  watch: {
    // 1) Jika UT-Daerah berubah, kategori yang terpilih sebelumnya tidak valid lagi
    filterUpbjj: function () {
      this.filterKategori = "";
    },

    // 2) Setiap data stok berubah (tambah/edit) catat waktu perubahan
    stok: {
      deep: true,
      handler: function () {
        this.terakhirDiubah = new Date().toLocaleTimeString("id-ID");
      }
    },

    // 3) Pesan notifikasi hilang otomatis setelah 3 detik
    pesan: function (nilaiBaru) {
      var self = this;
      if (nilaiBaru) {
        setTimeout(function () { self.pesan = ""; }, 3000);
      }
    }
  },

  // ---------- FILTER TEMPLATE ----------
  filters: {
    rupiah: function (angka) {
      return "Rp " + Number(angka).toLocaleString("id-ID");
    }
  },

  // ---------- METHODS ----------
  methods: {
    logout: function () {
      Auth.logout();
    },

    getStatus: function (item) {
      if (item.qty === 0) return "kosong";
      if (item.qty < item.safety) return "menipis";
      return "aman";
    },

    resetFilter: function () {
      this.filterUpbjj = "";
      this.filterKategori = "";
      this.filterReorder = false;
      this.sortBy = "judul";
      this.sortDir = "asc";
    },

    notifikasi: function (teks, tipe) {
      this.pesanTipe = tipe || "sukses";
      this.pesan = teks;
    },

    // Validasi sederhana; mengembalikan objek error (kosong = valid)
    validasi: function (d, baru) {
      var e = {};
      if (baru) {
        if (!d.kode) e.kode = "Kode wajib diisi.";
        else if (!/^[A-Z]{4,5}\d{4}$/.test(d.kode)) e.kode = "Format: 4-5 huruf kapital + 4 angka (mis. EKMA4116).";
        else if (this.stok.some(function (s) { return s.kode === d.kode; })) e.kode = "Kode sudah terdaftar.";

        if (!d.judul) e.judul = "Judul wajib diisi.";
        else if (d.judul.length < 3) e.judul = "Judul minimal 3 karakter.";

        if (!d.kategori) e.kategori = "Pilih kategori.";
        if (!d.upbjj) e.upbjj = "Pilih UT-Daerah.";
      }
      if (!d.lokasiRak) e.lokasiRak = "Lokasi rak wajib diisi.";
      else if (!/^R\d+-[A-Z]\d+$/.test(d.lokasiRak)) e.lokasiRak = "Format: R1-A3.";

      if (!adalahBilanganBulat(d.harga, 1)) e.harga = "Harga harus bilangan bulat > 0.";
      if (!adalahBilanganBulat(d.qty, 0)) e.qty = "Stok harus bilangan bulat >= 0.";
      if (!adalahBilanganBulat(d.safety, 0)) e.safety = "Safety stock harus bilangan bulat >= 0.";
      if (d.catatan && d.catatan.length > 200) e.catatan = "Maksimal 200 karakter.";
      return e;
    },

    // ----- Tambah -----
    tambahStok: function () {
      this.formErrors = this.validasi(this.form, true);
      if (Object.keys(this.formErrors).length > 0) {
        this.notifikasi("Periksa kembali isian formulir.", "bahaya");
        return;
      }
      var f = this.form;
      this.stok.push({
        kode: f.kode, judul: f.judul, kategori: f.kategori, upbjj: f.upbjj,
        lokasiRak: f.lokasiRak, harga: f.harga, qty: f.qty, safety: f.safety,
        catatanHTML: escapeHtml(f.catatan) // diescape agar input pengguna aman dipakai v-html
      });
      this.notifikasi("Bahan ajar " + f.kode + " berhasil ditambahkan.");
      this.resetForm();
      this.showAddForm = false;
    },

    resetForm: function () {
      this.form = formKosong();
      this.formErrors = {};
    },

    // ----- Edit -----
    bukaEdit: function (item) {
      this.editKode = item.kode;
      this.editErrors = {};
      this.editForm = {
        judul: item.judul, lokasiRak: item.lokasiRak, harga: item.harga,
        qty: item.qty, safety: item.safety,
        // ubah kembali HTML tampilan menjadi teks polos untuk diedit
        catatan: item.catatanHTML.replace(/<[^>]*>/g, "")
      };
    },

    simpanEdit: function () {
      this.editErrors = this.validasi(this.editForm, false);
      if (Object.keys(this.editErrors).length > 0) return;

      var kode = this.editKode;
      var target = this.stok.find(function (s) { return s.kode === kode; });
      var f = this.editForm;
      target.lokasiRak = f.lokasiRak;
      target.harga = f.harga;
      target.qty = f.qty;
      target.safety = f.safety;
      target.catatanHTML = escapeHtml(f.catatan);
      this.notifikasi("Stok " + kode + " berhasil diperbarui.");
      this.tutupEdit();
    },

    tutupEdit: function () {
      this.editKode = null;
      this.editForm = {};
      this.editErrors = {};
    }
  }
});
