// Logika Vue untuk index.html (beranda / dashboard)
new Vue({
  el: "#app",

  data: {
    user: Auth.wajibLogin(),
    jam: new Date().getHours()
  },

  computed: {
    salam: function () {
      if (this.jam < 11) return "Selamat Pagi";
      if (this.jam < 15) return "Selamat Siang";
      if (this.jam < 18) return "Selamat Sore";
      return "Selamat Malam";
    }
  },

  methods: {
    logout: function () {
      Auth.logout();
    }
  }
});
